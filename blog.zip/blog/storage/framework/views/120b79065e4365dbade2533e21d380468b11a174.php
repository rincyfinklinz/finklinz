
<?php $__env->startSection("page-content"); ?>
<form method="post" action="/articles/<?php echo e($article->id); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field("PUT"); ?>
    <div class="form-group">
       <label>Title</label>
<input type="text" name="title" value="<?php echo e($article->title); ?>" class="form-control">
    </div>
    <div class="form-group">
       <label> Description</label>
<textarea class="form-control" name="desc"  rows="" cols=""><?php echo e($article->description); ?></textarea>
</div>
<div class="form-group">
<button class="btn btn-primary">save</button>
</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rincy\blog\resources\views/articles/edit.blade.php ENDPATH**/ ?>
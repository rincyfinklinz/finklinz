
<?php $__env->startSection("title","About Page"); ?>
<?php $__env->startSection("page-content"); ?>
<p>This is a fruits</p>
<ul>
    <li>Apple</li>
    <li>Orange</li>
    <li>Grapes</li>
    <li>Gua</li>
    <li>Pineapple</li>
</ul>
<?php echo e($message); ?>

<ul>
<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($item); ?></li>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rincy\blog\resources\views/about.blade.php ENDPATH**/ ?>
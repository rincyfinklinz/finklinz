

<?php $__env->startSection("page-content"); ?>
<a href="/articles">View All</a>
<h1><?php echo e($article->title); ?></h1>
<p><?php echo e($article->description); ?></p>
<form method="post" action="/articles/<?php echo e($article->id); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field("DELETE"); ?>
    <button onclick="return confirm('are you sure..')">Delete</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rincy\blog\resources\views/articles/show.blade.php ENDPATH**/ ?>
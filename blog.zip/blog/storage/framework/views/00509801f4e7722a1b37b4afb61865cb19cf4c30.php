
<?php $__env->startSection("title","Contact Us"); ?>

<?php $__env->startSection("page-content"); ?>
<br>
Name<input type="text" name="name"><br>
Email<input type="email" name="email"><br>
Phone<input type="phone" name="phone"><br>
<input type="submit" value="submit">
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rincy\blog\resources\views/contact.blade.php ENDPATH**/ ?>
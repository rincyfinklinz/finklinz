<div class="links">
    <a href="/">Home</a>
    <a href="/about">About</a>
    <a href="/contact">Contact</a>
</div>
<div class="title-m-b-md"><?php echo $__env->yieldContent("title"); ?></div>
<?php echo $__env->yieldContent("post"); ?>

<div class="container">
    <?php echo $__env->yieldContent("page-content"); ?>
</div><?php /**PATH C:\Users\rincy\blog\resources\views/layouts/app.blade.php ENDPATH**/ ?>
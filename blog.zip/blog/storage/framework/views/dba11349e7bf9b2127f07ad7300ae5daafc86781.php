
<a href="articles/create">Add New Article</a>
<?php $__env->startSection("post"); ?>
<ul>
<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h1><a href="/articles/<?php echo e($article->id); ?>"><?php echo e($article->title); ?></a></h1>
<p><?php echo e($article->description); ?></p>

<a href="/articles/<?php echo e($article->id); ?>/edit">Edit</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rincy\blog\resources\views/articles/index.blade.php ENDPATH**/ ?>
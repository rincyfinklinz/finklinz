
<?php $__env->startSection("page-content"); ?>
<form method="post" action="/articles">
    <?php echo csrf_field(); ?>
    <div class="form-group">
       <label>Title</label>
<input type="text" name="title" class="form-control" required>
    </div>
    <div class="form-group">
       <label> Description</label>
<textarea class="form-control" name="desc" rows="" cols="" required></textarea>
</div>
<div class="form-group">
<button class="btn btn-primary">save</button>
</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rincy\blog\resources\views/articles/create.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


class PostsController extends Controller
{
    public function index($id)
    {
        $post = \DB::table('posts')->where("id",$id)->first();
        
        return view("post.index",$data);
    }
}
?>

@extends("layouts.app")
@section("page-content")
<form method="post" action="/articles">
    @csrf
    <div class="form-group">
       <label>Title</label>
<input type="text" name="title" class="form-control" required>
    </div>
    <div class="form-group">
       <label> Description</label>
<textarea class="form-control" name="desc" rows="" cols="" required></textarea>
</div>
<div class="form-group">
<button class="btn btn-primary">save</button>
</div>
</form>
@endsection

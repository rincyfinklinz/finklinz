@extends("layouts.app")
<a href="articles/create">Add New Article</a>
@section("post")
<ul>
@foreach ($articles as $article)
<h1><a href="/articles/{{$article->id}}">{{$article->title}}</a></h1>
<p>{{$article->description}}</p>

<a href="/articles/{{$article->id}}/edit">Edit</a>
@endforeach
</ul>

@endsection
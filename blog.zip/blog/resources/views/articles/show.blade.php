@extends("layouts.app")

@section("page-content")
<a href="/articles">View All</a>
<h1>{{$article->title}}</h1>
<p>{{$article->description}}</p>
<form method="post" action="/articles/{{$article->id}}">
    @csrf
    @method("DELETE")
    <button onclick="return confirm('are you sure..')">Delete</button>
</form>
@endsection
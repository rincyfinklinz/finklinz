@extends("layouts.app")
@section("page-content")
<form method="post" action="/articles/{{$article->id}}">
    @csrf
    @method("PUT")
    <div class="form-group">
       <label>Title</label>
<input type="text" name="title" value="{{$article->title}}" class="form-control">
    </div>
    <div class="form-group">
       <label> Description</label>
<textarea class="form-control" name="desc"  rows="" cols="">{{$article->description}}</textarea>
</div>
<div class="form-group">
<button class="btn btn-primary">save</button>
</div>
</form>
@endsection

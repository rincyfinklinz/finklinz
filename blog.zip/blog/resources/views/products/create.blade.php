@extends("layouts.app")
@section("page-content")
<form method="post" action="/api/products">
    @csrf
    <div class="form-group">
       <label>Title</label>
<input type="text" name="name" class="form-control" required>
    </div>
    <div class="form-group">
       <label> Description</label>
       <input type="number" name="price" class="form-control" required>
</div>
<div class="form-group">
<button class="btn btn-primary">save</button>
</div>
</form>
@endsection

@extends("layouts.app")
<a href="products/create">Add New Product</a>
@section("post")
<ul>
@foreach ($products as $product)
<h1><a href="/products/{{$product->id}}">{{$product->name}}</a></h1>
<p>{{$product->price}}</p>

<a href="/products/{{$product->id}}/edit">Edit</a>
@endforeach
</ul>

@endsection
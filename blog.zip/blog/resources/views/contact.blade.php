@extends("layouts.app")
@section("title","Contact Us")

@section("page-content")
<br>
Name<input type="text" name="name"><br>
Email<input type="email" name="email"><br>
Phone<input type="phone" name="phone"><br>
<input type="submit" value="submit">
@endsection
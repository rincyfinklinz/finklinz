@extends("layouts.app")
@section("title","About Page")
@section("page-content")
<p>This is a fruits</p>
<ul>
    <li>Apple</li>
    <li>Orange</li>
    <li>Grapes</li>
    <li>Gua</li>
    <li>Pineapple</li>
</ul>
{{$message}}
<ul>
@foreach ($items as $item)
<li>{{$item}}</li>

@endforeach
</ul>
@endsection


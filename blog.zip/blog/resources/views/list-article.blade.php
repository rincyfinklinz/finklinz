@extends("layouts.app")
@section("post")
<ul>
@foreach ($articles as $article)
<li>{{$article->title}}</li>
{{$article->description}}<br>
{{$article->created_at}}
@endforeach
</ul>
@endsection
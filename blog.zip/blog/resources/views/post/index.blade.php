@foreach ($items as $item)
<li>{{$item}}</li>

@endforeach
<div class="links">
    <a href="/">Home</a>
    <a href="/about">About</a>
    <a href="/contact">Contact</a>
</div>
<div class="title-m-b-md">@yield("title")</div>
@yield("post")

<div class="container">
    @yield("page-content")
</div>